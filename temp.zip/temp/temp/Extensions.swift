//
//  Extensions.swift
//  DeutschGramma
//
//  Created by Anne Dyer on 30.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

extension UIColor
{
    convenience init(red: Int, green: Int, blue: Int)
    {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    convenience init(netHex: Int)
    { self.init(red:(netHex >> 16) & 0xff, green:(netHex >> 8) & 0xff, blue:netHex & 0xff) }
}
extension UIColor
{
    struct Words {
        static let verb = UIColor(netHex: 0xff0000)
        static let noun = UIColor.blue
        static let subject = UIColor(netHex: 0x0000ff)
        static let object = UIColor(netHex: 0x1e5900)
        static let indirectObject = UIColor(netHex: 0x369d01)
        static let genitive = UIColor(netHex: 0x783f04)
        static let article = UIColor(netHex: 0xff6500)
        static let adjective = UIColor(netHex: 0x9900ff)
        static let adverb = UIColor(netHex: 0xff00ff)
        static let generic = UIColor(netHex: 0x70747a)
    }
}

//extension NSUserInterfaceItemIdentifier
//{
//    static let myCReusableV = NSUserInterfaceItemIdentifier("MyCReusableV")
//}
