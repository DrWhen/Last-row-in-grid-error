//
//  NounsTVC.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 18.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class EndingsTVC: UITableViewController
{
//    let collectionContents = EndingCollectionContent()
//
//    fileprivate var tableViewCellCoordinator: [Int: IndexPath] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("hello")
        // Self-sizing magic!
        self.tableView.rowHeight = UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 100; //Set this to any value that works for you.
        self.tableView.register(UINib.init(nibName: "CVTVCell", bundle: nil), forCellReuseIdentifier: "CVTVCell")
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
       // endingsCV.collectionViewLayout.invalidateLayout()
        // myCollectionView.collectionViewLayout.invalidateLayout()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CVTVCell") as! CVTVCell
        return cell
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
}
