//
//  CVTVCell.swift
//  DeutschGramma
//
//  Created by Anne Dyer on 29.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

private let reuseI4CVCell = "CVCell"
private let reuseI4PickerCVCell = "PickerCVCell"
private let reuseI4MyCReusableV = "MyCReusableV"

class CVTVCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    var collectionContents = Endings()
    var currentContents: [EndingData] = []
    
    fileprivate var tableViewCellCoordinator: [Int: IndexPath] = [:]
    
    @IBOutlet weak var cView: UICollectionView!
    
    @IBOutlet weak var cViewFlowLayout: UICollectionViewFlowLayout!

//    @IBOutlet weak var collectionView: UICollectionView!
//    @IBOutlet weak var collectionViewFlowLayout: UICollectionViewFlowLayout!
//
//    @IBOutlet weak var label: UILabel!
    
    func myPickerDidSelectRow(selectedRowValue: Int?)
    {
        currentContents = collectionContents.allEndings[selectedRowValue ?? 0]
        print(selectedRowValue ?? "could't say which selected row")
        cView.reloadData()
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
        
        self.cView.dataSource = self
        self.cView.delegate = self
        
        self.cView.register(UINib.init(nibName: reuseI4CVCell, bundle: nil), forCellWithReuseIdentifier: reuseI4CVCell)
        self.cView.register(UINib.init(nibName: reuseI4PickerCVCell, bundle: nil), forCellWithReuseIdentifier: reuseI4PickerCVCell)
//        self.cView.register(MyCReusableV.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "MyCReusableV")
        self.cView.register(UINib.init(nibName: reuseI4MyCReusableV, bundle: nil), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: reuseI4MyCReusableV)
        
        currentContents = collectionContents.allEndings[0]
    }
    
    // ??? do any of these methods manage rotation of device for all devices??? 
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)

        guard previousTraitCollection != nil else {
            return
        }
        cView.collectionViewLayout.invalidateLayout()
        cView.reloadData()
    }
    
    override func willTransition(to state: UITableViewCell.StateMask) {
        super.willTransition(to: state)
        cView.collectionViewLayout.invalidateLayout()
    }
    
  
    func willRotateToInterfaceOrientation(toInterfaceOrientation: UIInterfaceOrientation, duration: TimeInterval) {
        cView.collectionViewLayout.invalidateLayout()
        cView.reloadData()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    { return 1 }
    
    func collectionView( _ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    { return currentContents.count }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseI4CVCell, for: indexPath) as! CVCell
        
        let settings = currentContents[indexPath.item]
        let text = settings.text
        let attributedText = NSMutableAttributedString(string: text)
        
        let colorAttribute1: [NSAttributedString.Key : Any] = [.foregroundColor : settings.color1 as Any]
        attributedText.setAttributes(colorAttribute1, range: settings.colorRange1 ?? NSRange(location: 0, length: attributedText.length))
        if let color2 = settings.color2
        {
            let colorAttribute2: [NSAttributedString.Key : Any]  = [.foregroundColor : color2]
            attributedText.setAttributes(colorAttribute2, range: settings.colorRange2 ?? NSRange(location: 5, length: attributedText.length))
        }
        if let color3 = settings.color3
        {
            let colorAttribute3: [NSAttributedString.Key : Any]  = [.foregroundColor : color3]
            attributedText.setAttributes(colorAttribute3, range: settings.colorRange3 ?? NSRange(location: 5, length: attributedText.length))
        }
        
        if let underlineRange1 = settings.underlineRange1
        { attributedText.addAttribute(NSAttributedString.Key.underlineStyle,
                                      value: NSUnderlineStyle.single.rawValue,
                                      range: underlineRange1) }
        if let underlineRange2 = settings.underlineRange2
        { attributedText.addAttribute(NSAttributedString.Key.underlineStyle,
                                      value: NSUnderlineStyle.single.rawValue,
                                      range: underlineRange2) }
        if let underlineRange3 = settings.underlineRange3
        { attributedText.addAttribute(NSAttributedString.Key.underlineStyle,
                                      value: NSUnderlineStyle.single.rawValue,
                                      range: underlineRange3) }
        
        // Add other attributes if needed
        
        cell.label.attributedText = attributedText
        
        cell.contentView.layer.cornerRadius = 5
        cell.contentView.layer.borderWidth = 0.5
        
        cell.contentView.layer.borderColor = UIColor.gray.cgColor
        cell.contentView.layer.masksToBounds = true
            
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        let settings = currentContents[indexPath.item]
        let height = CGFloat(30)
        
        // https://stackoverflow.com/questions/54915227/uicollectionview-remove-space-between-cells-with-7-items-per-row
        var cellWidth = CGFloat()
        var availableWidth = CGFloat(700)
        print("frame", collectionView.bounds.size.width)
        if collectionView.bounds.size.width < 700
        { availableWidth = collectionView.bounds.size.width }
        print("available width", availableWidth)
        let minimumWidth = floor(availableWidth / collectionContents.cellsPerRow5)
        // let remainder = availableWidth - minimumWidth * CGFloat(cellsPerRow4)
        print("minmum width", minimumWidth)
        cellWidth = minimumWidth * settings.portion - 0.5
        print("cell width", cellWidth)
        
        return CGSize(width: cellWidth, height: height)
    }
    
//    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView
//    {
//        switch kind
//        {
//        case UICollectionView.elementKindSectionHeader:
//            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: reuseI4MyCReusableV, for: indexPath) as? MyCReusableV
//            headerView?.headerPicker.delegate = headerView
//            headerView?.headerPicker.dataSource = headerView
//            headerView?.reference = self
//            return headerView!
//        default:
//            assert(false, "also invalid view Type")
//        }
//        let sectionHeader = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "MyCReusableV", for: indexPath) as! MyCReusableV
////        sectionHeader.headerPicker.delegate = sectionHeader
////        sectionHeader.headerPicker.dataSource = sectionHeader
//        return sectionHeader
//    }
}
