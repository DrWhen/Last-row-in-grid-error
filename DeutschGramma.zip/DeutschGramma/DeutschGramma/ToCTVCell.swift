//
//  ToCTVCell.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 01.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

protocol ToContentTVCellDelegate
{ func didSelectToContentTVCell(Selected: Bool, UserHeader: ToContentTVCell) }

class ToContentTVCell: UITableViewCell
{
    var delegate : ToContentTVCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    @IBAction func selectedHeader(sender: AnyObject) {
        delegate?.didSelectToContentTVCell(Selected: true, UserHeader: self)
        
    }
}
