//
//  GridTVCell.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 18.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class GridTVCell: UITableViewCell
{
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 20, left: 2, bottom: 10, right: 2)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
   //     collectionView!.collectionViewLayout = layout
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
