//
//  EndingsExamplesModel.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 08.05.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

//protocol Content
//{
//    var heading: String { get }
//    var subHeading: String? { get }
//}
//}

struct EgEndingsData
{
    let text: String
    let color1: UIColor?
    let color2: UIColor?
    let color3: UIColor?
    let colorRange1: NSRange?
    let colorRange2: NSRange?
    let colorRange3: NSRange?
    let underlineRange1: NSRange?
    let underlineRange2: NSRange?
    let underlineRange3: NSRange?
}

//class EgNominativeEndings
//{
//    let masculineEndingsEgs: [EgEndingsData]
//    let neutralEndingsEgs: [EgEndingsData]
//    let feminineEndingsEgs: [EgEndingsData]
//    let genitiveEndingsEgs: [EgEndingsData]
//    
//    var allEgEndings = [[EndingData]]()
//    let cellsPerRow = CGFloat(4)
//    
//    init(masculineEndingsEg: [EgEndingsData], neutralEndings: [EgEndingsData], feminineEndingsEgs: [EgEndingsData], genitiveEndingsEg: [EgEndingsData]) {
//        <#statements#>
//    }
//    
//}
