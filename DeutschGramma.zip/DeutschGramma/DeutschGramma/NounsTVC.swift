//
//  NounsTVC.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 18.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class NounsTVC: UITableViewController {
//    
    let cellIds = ["Position1","MainVerb","Position2","Position3","Subject","Main Verb2", "Objects", "Indirect Os","Eg Pos1","Eg Main Verb", "Eg Pos2", "Eg Pos3", "EN Pos1", "EN Main Verb", "EN Pos2", "EN Pos3"]
    // let cellSizes = Array( repeatElement(CGSize(width:80, height:50), count: 4))
    
//    let cellSizes = [
//            CGSize(width: 110, height: 30),
//            CGSize(width: 120, height: 30),
//            CGSize(width: 110, height: 30),
//            CGSize(width: 130, height: 30)
//        ]
    let cellPortions = [
            CGFloat(1.4),
            CGFloat(0.8),
            CGFloat(0.8),
            CGFloat(1.0),
            CGFloat(1.4),
            CGFloat(0.8),
            CGFloat(0.8),
            CGFloat(1.0),
            CGFloat(1.4),
            CGFloat(0.8),
            CGFloat(0.8),
            CGFloat(1.0),
            CGFloat(1.4),
            CGFloat(0.8),
            CGFloat(0.8),
            CGFloat(1.0),
    ]
    
    let cellsPerRow4 = CGFloat(4)
//

//    let cellIds2 = ["Blank Cell","Masculine","Neutral","Feminine","Plural","Nominative", "er", "s","e","e2", "Accusative", "en", "s2", "e3", "e4","Dative","em","em2","er2","en2","Genitive","es","es2","er3","er4"]
//    // let cellSizes = Array( repeatElement(CGSize(width:80, height:50), count: 4))
//
////    let cellSizes = [
////        CGSize(width: 110, height: 30),
////        CGSize(width: 120, height: 30),
////        CGSize(width: 110, height: 30),
////        CGSize(width: 130, height: 30)
////    ]
//    let cellPortions2 = [
//        CGFloat(1.4),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(1.4),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(1.4),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(1.4),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(1.4),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(1.4),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(1.4),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//        CGFloat(0.9),
//    ]
//
//    let cellsPerRow5 = CGFloat(5)
    
//    let dataSourceAndDelegate = SelfSizingCVController()
//
 
    @IBOutlet weak var nounCV: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("hello")

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()

//        endingsCV.collectionViewLayout.invalidateLayout()
         nounCV.collectionViewLayout.invalidateLayout()
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 6
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension NounsTVC: UICollectionViewDataSource
{
    func collectionView( _ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        print("boogie", cellIds.count)
        return cellIds.count
    }
    
    func collectionView( _ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        
        let cell = collectionView.dequeueReusableCell( withReuseIdentifier: cellIds[indexPath.item], for: indexPath)
   //     cell.layer.borderColor = UIColor.gray.cgColor
   //     cell.layer.borderWidth = 0.5
        
        
        cell.contentView.layer.cornerRadius = 5
        cell.contentView.layer.borderWidth = 0.5
        
        cell.contentView.layer.borderColor = UIColor.gray.cgColor
        cell.contentView.layer.masksToBounds = true
        
    //    cell.layer.shadowColor = UIColor.gray.cgColor
    //    cell.layer.shadowOffset = CGSize(width: 0, height: 2.0)
    //    cell.layer.shadowRadius = 2.0
    //    cell.layer.shadowOpacity = 1.0
//        cell.layer.masksToBounds = false
//        cell.layer.shadowPath = UIBezierPath(roundedRect:cell.bounds, cornerRadius:cell.contentView.layer.cornerRadius).cgPath
        
        return cell
    }
}

extension NounsTVC: UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        var cellWidth = CGFloat()
        let availableWidth = collectionView.bounds.size.width
  
        let minimumWidth = floor(availableWidth / cellsPerRow4)
           // let remainder = availableWidth - minimumWidth * CGFloat(cellsPerRow4)
            
        let columnIndex = indexPath.item % Int(cellsPerRow4)      // https://stackoverflow.com/questions/54915227/uicollectionview-remove-space-between-cells-with-7-items-per-row
            cellWidth = minimumWidth * cellPortions[indexPath.item] - 1
            print(cellWidth, columnIndex)
        
        return CGSize(width: cellWidth, height: 30)
        
        //   let cellWidth = CGFloat(columnIndex) < remainder ? ((minimumWidth * cellPortions[indexPath.item]) + 1) : minimumWidth

//        let screenWidth = screenSize.width
//        return CGSize(width: screenWidth / 4, height: CGFloat(30))
        //return CGSize(width: CGFloat((collectionView.bounds.size.width / 4)), height: CGFloat(30))
            //frame.size.width / 4) - 20), height: CGFloat(30))
    }
 //       return CGSize(width: CGFloat((cellSizes[indexPath.item].width) - 25), height: CGFloat(cellSizes[indexPath.item].height))
//
//    {
//        print(cellSizes[indexPath.item])
//        let cellWidth = cellSizes[indexPath.item]
//
//        return CGSize(width: CGFloat(cellWidth - 20), height: 50)
////    { return cellSizes[indexPath.item] }
//    }
}

extension NounsTVC: UICollectionViewDelegate
{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    { print("User tapped on (cellIds[indexPath.row])") }
}

//class CustomViewFlowLayout : UICollectionViewFlowLayout
//{
//    let cellSpacing:CGFloat = 4
//
//    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]?
//    {
//        if let attributes = super.layoutAttributesForElements(in: rect)
//        {
//            for (index, attribute) in attributes.enumerated()
//            {
//                if index == 0 { continue }
//                let prevLayoutAttributes = attributes[index - 1]
//                let origin = CGRect.maxX(prevLayoutAttributes.frame)
//                if(origin + cellSpacing + attribute.frame.size.width < self.collectionViewContentSize().width) {
//                    attribute.frame.origin.x = origin + cellSpacing
//                }
//            }
//            return attributes
//        }
//        return nil
//    }
//}
