//
//  CVCell.swift
//  DeutschGramma
//
//  Created by Anne Dyer on 29.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class CVCell: UICollectionViewCell
{
    @IBOutlet weak var label: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }
}
