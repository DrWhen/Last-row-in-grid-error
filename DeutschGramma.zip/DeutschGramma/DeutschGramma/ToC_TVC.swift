//
//  ToC_TVC.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 01.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

extension UITableView {
    
    override open func didMoveToSuperview() {
        super.didMoveToSuperview()
        self.tableFooterView = UIView(frame: .zero)
    }
}

class ToCTVC: UITableViewController
{
    // get my data
    var tableOfContent: [Contents]
    { return Contents.sections() }
    /* would create an array of Content via methods defined in Contents
    var contents: [Content] {
        var listOfHeadings = Contents.sections()
        return listOfHeadings[0].headings ?? [Content(heading: "Not found", subHeading: "Not found")]
    } */
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int
    { return tableOfContent.count }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        let section = tableOfContent[section]
        return section.headings.count
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
//        var header = tableView.dequeueReusableCellWithIdentifier("userheader") as ToContentTVCell
//        header.delegate = self
        
        let v = UITableViewHeaderFooterView()
        let tapRecognizer = MyTapGesture(target: self, action: #selector(handleTap))
        tapRecognizer.sectionName = tableOfContent[section].topic
        v.addGestureRecognizer(tapRecognizer)
        return v
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        let section = tableOfContent[section]
        return section.topic
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Content Cell", for: indexPath)
        
        let sectionHeading = tableOfContent[indexPath.section]

        let content = sectionHeading.headings[indexPath.row]
//        {
        cell.textLabel?.text = content.heading
        cell.detailTextLabel?.text = content.subHeading
//        }
        return cell
    }

    // MARK: - Table view delegate

    @objc func handleTap(sender: MyTapGesture)
    {
        let topic = sender.sectionName
        let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: topic)
        self.present(viewController, animated: false, completion: nil)
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let sectionContents = tableOfContent[indexPath.section]
        if let identifier = sectionContents.headings[indexPath.row].heading
        {
            let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: identifier)
            self.present(viewController, animated: false, completion: nil)
        }
    }
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
}
