//
//  GridCView.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 18.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class GridCView: UICollectionView
{

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
