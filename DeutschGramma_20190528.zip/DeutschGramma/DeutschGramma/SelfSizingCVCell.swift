//
//  SelfSizingCVCell.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 24.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit

class SelfSizingCVCell: UICollectionViewCell
{
    override func preferredLayoutAttributesFitting(_ layoutAttributes: UICollectionViewLayoutAttributes) -> UICollectionViewLayoutAttributes {
        // toggle autolayout
        setNeedsLayout()
        layoutIfNeeded()
        
        let size = contentView.systemLayoutSizeFitting(layoutAttributes.size)
        var frame = layoutAttributes.frame
        frame.size.height = ceil(size.height)
        layoutAttributes.frame = frame
        
        return layoutAttributes
    }
}
