//
//  Classes.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 05.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import Foundation
import UIKit

class MyTapGesture: UITapGestureRecognizer
{
    var sectionName = String()
}
