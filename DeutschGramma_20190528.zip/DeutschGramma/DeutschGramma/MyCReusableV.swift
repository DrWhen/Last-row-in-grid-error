//
//  MyCReusableV.swift
//  DeutschGramma
//
//  Created by Anne Dyer on 02.05.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import UIKit


protocol MyPickerVProtocol
{ func myPickerDidSelectRow(selectedRowValue: Int?) }

class MyCReusableV: UICollectionReusableView, UIPickerViewDelegate, UIPickerViewDataSource
{
    let endings = EndingsPicker()
    var reference: MyPickerVProtocol?
    
    @IBOutlet weak var headerPicker: UIPickerView!

    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
        print("in reusable")
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    { return 1 }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    { return endings.pickerData.count }
    
    //    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
    //        return pickerData[row]
    //    }
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView
    {
        let settings = endings.pickerData[row]
        
        let text = settings.text
        let attributedText = NSMutableAttributedString(string: text)
        
        var pickerLabel: UILabel? = (view as? UILabel)
        if pickerLabel == nil
        {
            pickerLabel = UILabel()
            pickerLabel?.font = UIFont(name: "Arial-Bold", size: 20)
            pickerLabel?.textAlignment = .left
            
            let colorAttribute1: [NSAttributedString.Key : Any] = [.foregroundColor : settings.rowColor1]
            attributedText.setAttributes(colorAttribute1, range: settings.colorRange1 ?? NSRange(location: 0, length: attributedText.length))
            if let color2 = settings.rowColor2
            {
                let colorAttribute2: [NSAttributedString.Key : Any]  = [.foregroundColor : color2]
                attributedText.setAttributes(colorAttribute2, range: settings.colorRange2 ?? NSRange(location: 5, length: attributedText.length))
            }
         }
        pickerLabel?.attributedText = attributedText
        
        print("picker label", pickerLabel as Any)
        return pickerLabel!
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        //get your picker values that you need
       // let theRowValue = endings.pickerData[row]
        reference?.myPickerDidSelectRow(selectedRowValue: row)
    }
}
