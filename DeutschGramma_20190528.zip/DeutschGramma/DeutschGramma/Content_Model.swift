//
//  ToC_Model.swift
//  DeutschGramma
//
//  Created by Christopher Dyer on 01.04.19.
//  Copyright © 2019 Christopher Dyer. All rights reserved.
//

import Foundation

//protocol Content
//{
//    var heading: String { get }
//    var subHeading: String? { get }
//}
//}
class Content
{
    var heading: String?
    var subHeading: String?

    init(heading: String, subHeading: String)
    {
        self.heading = heading
        self.subHeading = subHeading
    }
}

class Contents
{
    var topic: String!              // the major topic
    var headings: [Content]        // list of sub topics

    init(topicHere: String, headingsHere: [Content]?)
    {
        topic = topicHere
        headings = headingsHere ?? [Content(heading: "Swift the aweful language", subHeading: "We're all still learning")]
    }
    
    class func sections() -> [Contents]
    {
        return [self.sentences(), self.nouns(), self.verbs(), self.cases()]
    }    
    
    private class func sentences() -> Contents
    {
        var contents = [Content]()
        
        contents.append(Content(heading: "Basic", subHeading: "I do!"))
        contents.append(Content(heading: "Nebensatz", subHeading: "The subordinate clause!"))
        contents.append(Content(heading: "Coordinating Conjunctions", subHeading: "Simple joining words (eg 'and')"))
        
        return Contents(topicHere: "Sentences", headingsHere: contents)
    }
    
    private class func nouns() -> Contents
    {
        var contents = [Content]()
        
        contents.append(Content(heading: "Genders", subHeading: "How to sex a noun!"))
        contents.append(Content(heading: "Article and Adjective Endings", subHeading: "Die schreckliche Sprache - part 1"))
        
        return Contents(topicHere: "Nouns", headingsHere: contents)
    }
    
    private class func verbs() -> Contents
    {
        var contents = [Content]()
        contents.append(Content(heading: "Regular", subHeading: "Congugate regularly"))
        contents.append(Content(heading: "Irregular", subHeading: "Congugate till it hurts"))
        contents.append(Content(heading: "Modal", subHeading: "You can, like, should, will, want, may and must end with another verb"))
        contents.append(Content(heading: "Separable", subHeading: "Output puts it out"))
        
        return Contents(topicHere: "Verbs", headingsHere: contents)
    }
    
    private class func cases() -> Contents
    {
        var contents = [Content]()
        
        contents.append(Content(heading: "Nominative", subHeading: "The subject is the subject"))
        contents.append(Content(heading: "Accusative", subHeading: "The subject has an object"))
        contents.append(Content(heading: "Dative", subHeading: "The subject helps an indirect object"))
        contents.append(Content(heading: "Genative", subHeading: "The noun's possession"))
        
        return Contents(topicHere: "Cases", headingsHere: contents)
    }
}
